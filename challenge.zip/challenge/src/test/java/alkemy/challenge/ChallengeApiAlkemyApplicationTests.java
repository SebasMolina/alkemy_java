package alkemy.challenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengeApiAlkemyApplicationTests {

	@Test
	void contextLoads() {
	}

}
