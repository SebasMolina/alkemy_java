package alkemy.challenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChallengeApiAlkemyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChallengeApiAlkemyApplication.class, args);
	}

}
